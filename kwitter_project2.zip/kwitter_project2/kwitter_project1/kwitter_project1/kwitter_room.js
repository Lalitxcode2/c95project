const firebaseConfig = {
    apiKey: "AIzaSyD9FJKcELLAH2-2DXA7GIDOls98S2keT18",
    authDomain: "lalit-kwitter.firebaseapp.com",
    databaseURL: "https://lalit-kwitter-default-rtdb.firebaseio.com",
    projectId: "lalit-kwitter",
    storageBucket: "lalit-kwitter.appspot.com",
    messagingSenderId: "589649974143",
    appId: "1:589649974143:web:fae44b57d7325598aec04a"
  };
  firebase.initializeApp(firebaseConfig);

  get_username = localStorage.getItem("user name");
  document.getElementById("welcome").innerHTML= "Welcome " + get_username + "!";

function adding_room(){
    roomname = document.getElementById("room").value;
    firebase.database().ref("/").child(roomname).update({
        purpose:"adding room name"
    });
    localStorage.setItem("room name",roomname);
    window.location="kwitter_page.html";
    }

function getData() {firebase.database().ref("/").on('value', function(snapshot) {document.getElementById("display").innerHTML = "";snapshot.forEach(function(childSnapshot) {childKey  = childSnapshot.key;
     Room_names = childKey;
    //Start code
    console.log("Room Name :" + Room_names);
    row = "<div class='room' id="+Room_names+" onclick='redirectToRoomName(this.id)'>#" +Room_names +"</div> <hr>";
    document.getElementById("display").innerHTML += row;
    //End code
    });});}
getData();

function redirectToRoomName(roomname){
    console.log("Room Name :" + roomname); 
    localStorage.setItem("room name",roomname);
    window.location="kwitter_page.html"; 
}