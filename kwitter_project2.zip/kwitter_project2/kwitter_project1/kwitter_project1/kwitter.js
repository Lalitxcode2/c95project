function add_user(){
    user_name1 = document.getElementById("name").value;
    
    localStorage.setItem("user name",user_name1);
    
     window.location= "kwitter_room.html";
    }
    